<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LigneProjetController extends Controller
{
    //
}
