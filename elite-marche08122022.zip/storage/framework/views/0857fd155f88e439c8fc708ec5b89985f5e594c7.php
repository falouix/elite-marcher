<?php if($valider == false): ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('besoin-edit')): ?>
    <button type="button" data-id='<?php echo e($id); ?>' id="tbl_btn_delete" class="btn btn-icon btn-rounded btn-danger"
        title="<?php echo e(__('inputs.btn_edit')); ?>" onclick="editLigneBesoin(<?php echo e($id); ?>)">
        <i class="feather icon-edit"></i>
    </button>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('besoin-delete')): ?>
    <button type="button" data-id='<?php echo e($id); ?>' id="tbl_btn_delete" class="btn btn-icon btn-rounded btn-danger"
        title="<?php echo e(__('inputs.btn_delete')); ?>" onclick="deleteFromDataTableLigneBesoinBtn(<?php echo e($id); ?>)">
        <i class="feather icon-trash-2"></i>
    </button>
<?php endif; ?>
<?php endif; ?>
<?php /**PATH F:\MesProjetsLaravel\elite-marche\resources\views/besoins/lignebesoin-datatable-actions.blade.php ENDPATH**/ ?>