<?php switch($type_dossier):
    case ('CONSULTATION'): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('consultations-view')): ?>
            <a href="<?php echo e(route('consultations.show', ['consultation' => $id])); ?>" class="btn btn-icon btn-rounded btn-primary"
                title="<?php echo e(__('inputs.btn_view')); ?>">
                <i class="feather icon-eye"></i>
            </a>
        <?php endif; ?>
    <?php break; ?>

    <?php case ('AOS'): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('AOS-view')): ?>
            <a href="<?php echo e(route('consultations.show', ['consultation' => $id])); ?>" class="btn btn-icon btn-rounded btn-primary"
                title="<?php echo e(__('inputs.btn_view')); ?>">
                <i class="feather icon-eye"></i>
            </a>
        <?php endif; ?>
    <?php break; ?>

    <?php case ('AON'): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('AON-view')): ?>
            <a href="<?php echo e(route('AON.show', ['consultation' => $id])); ?>" class="btn btn-icon btn-rounded btn-primary"
                title="<?php echo e(__('inputs.btn_view')); ?>">
                <i class="feather icon-eye"></i>
            </a>
        <?php endif; ?>
    <?php break; ?>

    <?php case ('AOGREGRE-view'): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('besoin-edit')): ?>
            <a href="<?php echo e(route('consultations.show', ['consultation' => $id])); ?>" class="btn btn-icon btn-rounded btn-primary"
                title="<?php echo e(__('inputs.btn_view')); ?>">
                <i class="feather icon-eye"></i>
            </a>
        <?php endif; ?>
    <?php break; ?>

<?php endswitch; ?>
<?php /**PATH F:\MesProjetsLaravel\elite-marche\resources\views/dossiers_achats/dhasboard-actions.blade.php ENDPATH**/ ?>