<?php
if ($locale == 'ar') {
    $name = 'name_' . $locale;
    $lang = asset('/plugins/i18n/Arabic.json');
} else {
    $name = 'name';
    $lang = '';
}
$breadcrumb = __('breadcrumb.bread_role');
$tbl_action = __('labels.tbl_action');

?>

<?php $__env->startSection('head-script'); ?>

<!-- data tables css -->
<link rel="stylesheet" href="<?php echo e(asset('/plugins/data-tables/css/datatables.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/plugins/data-tables/css/select.dataTables.min.css')); ?>">
<!-- pnotify css -->
<link rel="stylesheet" href="<?php echo e(asset('/plugins/pnotify/css/pnotify.custom.min.css')); ?>">
<!-- pnotify-custom css -->
<link rel="stylesheet" href="<?php echo e(asset('/css/pages/pnotify.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php echo $__env->make('layouts.partials.breadcrumb', [
    'bread_title'=> $breadcrumb,
    'bread_subtitle'=> $breadcrumb
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <!-- Column Selector table start -->
    <div class="col-sm-12">
        <div class="card">

            <div class="card-header">
                <h5><?php echo e(__('cards.role_list')); ?></h5>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-create')): ?>
                <a class="btn btn-danger float-right" href="#"> <i class="feather icon-trash-2"></i> <?php echo e(__('inputs.btn_delete')); ?></a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-create')): ?>
                <a class="btn btn-primary float-right" href="<?php echo e(route('roles.create')); ?>"> <i class="feather icon-plus-circle"></i> <?php echo e(__('inputs.btn_create')); ?></a>
                <?php endif; ?>

            </div>
            <div class="card-body">
                <div class="dt-responsive table-responsive">
                    <table id="colum-select" class="table table-striped table-bordered nowrap">
                        <thead>
                            <th></th>
                            <th><?php echo e(__('labels.tbl_libelle')); ?></th>
                            <th ><?php echo e(__('labels.tbl_created_at')); ?></th>
                            <th><?php echo e($tbl_action); ?></th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>

                                    <td></td>
                                    <td><?php echo e($role->name); ?></td>
                                    <td><?php echo e($role->created_at->format('Y-m-d')); ?></td>
                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-edit')): ?>
                                            <a class="btn btn-icon btn-rounded btn-success" href="<?php echo e(route('roles.edit', $role->id)); ?>"
                                                title="<?php echo e(__('inputs.btn_edit')); ?>">
                                                <i class="feather icon-edit"></i>
                                            </a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-delete')): ?>
                                            <?php echo Form::open(['method' => 'DELETE', 'route' => ['roles.destroy', $role->id], 'style' => 'display:inline']); ?>


                                            <button type="submit" class="btn btn-icon btn-rounded btn-danger" title="<?php echo e(__('inputs.btn_delete')); ?>">
                                                <i class="feather icon-trash-2"></i>
                                            </button>

                                            <?php echo Form::close(); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th></th>
                                <th><?php echo e(__('labels.tbl_libelle')); ?></th>
                            <th ><?php echo e(__('labels.tbl_created_at')); ?></th>
                            <th><?php echo e($tbl_action); ?></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- Column Selector table end -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('srcipt-js'); ?>
    <!-- datatable Js -->
    <script src="<?php echo e(asset('/plugins/data-tables/js/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/plugins/data-tables/js/dataTables.select.min.js')); ?>"></script>
    <!-- pnotify Js -->
    <script src="<?php echo e(asset('/plugins/pnotify/js/pnotify.custom.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        $('#colum-select').DataTable({

          columnDefs: [{
            orderable: true,
            className: 'select-checkbox',
            targets: 0
          }],
          language: {
            url: "<?php echo e($lang); ?>"
        },
          select: {
            style: 'os',
            selector: 'td:first-child'
          }
        });
        $('.dataTables_length').addClass('bs-select');
      });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\MesProjetsLaravel\elite-marche\resources\views/roles/index.blade.php ENDPATH**/ ?>