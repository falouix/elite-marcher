<title><?php echo e(__('app.app_name')); ?> - <?php echo $__env->yieldContent('page_title'); ?></title>
<!-- HTML5 Shim and Respond.js IE11 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 11]>
  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
  <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
  <![endif]-->
<!-- Meta -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description"
content="منظوم التصرف في الصفقات العمومية جامعة جندوبة"/>
<meta name="keywords"
    content="منظوم التصرف في الصفقات العمومية جامعة جندوبة">
    <meta name="author" content="CDF Center- Chedli Elhaj Ali" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<!-- Favicon icon

<!-- fontawesome icon -->
<link rel="stylesheet" href="<?php echo e(asset('/fonts/fontawesome/css/fontawesome-all.min.css')); ?>">
<!-- animation css -->
<link rel="stylesheet" href="<?php echo e(asset('/plugins/animation/css/animate.min.css')); ?>">

<!-- vendor css -->
<link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
<!-- vendor css -->
<link rel="stylesheet" href="<?php echo e(asset('/css/pages/pages.css')); ?>">
<!-- RTL css -->
<?php if(LaravelLocalization::getCurrentLocale() == 'ar'): ?>
    <link rel="stylesheet" href="<?php echo e(asset('/css/layouts/rtl.css')); ?>">
<?php endif; ?>


<?php /**PATH F:\MesProjetsLaravel\elite-marche\resources\views/layouts/partials/head.blade.php ENDPATH**/ ?>