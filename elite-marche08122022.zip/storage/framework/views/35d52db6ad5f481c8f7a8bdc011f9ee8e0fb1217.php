<?php if($docs_id): ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('besoin-file-edit')): ?>
<a href="<?php echo e(route('file.upload.get',['id'=>$docs_id,'param'=>'besoin_documents'])); ?>" class="btn btn-icon btn-rounded btn-primary"
    title="<?php echo e(__('inputs.btn_view_file')); ?>" target="_blank" >
        <i class="feather icon-eye"></i>
    </a>
<?php endif; ?>
<?php endif; ?>
<?php /**PATH F:\MesProjetsLaravel\elite-marche\resources\views/besoins/pais/file-actions.blade.php ENDPATH**/ ?>