<?php if($docs_id): ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-edit')): ?>
<a href="<?php echo e(route('file.upload.get',['id'=>$docs_id,'param'=>'besoin_documents'])); ?>" class="btn btn-icon btn-rounded btn-primary"
    title="<?php echo e(__('inputs.btn_view_file')); ?>" target="_blank" >
        <i class="feather icon-eye"></i>
    </a>
<?php endif; ?>
<?php endif; ?>

<button type="button" data-id='<?php echo e($id); ?>' id="tbl_btn_delete" class="btn btn-icon btn-rounded btn-danger"
title="<?php echo e(__('inputs.btn_delete')); ?>" onclick="deleteFromDataTableBtn(<?php echo e($id); ?>)">
<i class="feather icon-trash-2"> </i>
</button>
<?php /**PATH F:\MesProjetsLaravel\elite-marche\resources\views/projets/lignes_projets/ligneprojet-datatable-actions.blade.php ENDPATH**/ ?>