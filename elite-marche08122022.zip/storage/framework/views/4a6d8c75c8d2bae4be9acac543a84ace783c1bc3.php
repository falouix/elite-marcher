<?php echo e($slot); ?>

<?php /**PATH F:\MesProjetsLaravel\elite-marche\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>