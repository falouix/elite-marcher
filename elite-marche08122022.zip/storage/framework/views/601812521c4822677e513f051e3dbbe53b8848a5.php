<?php

$breadcrumb = __('breadcrumb.bread_user');
if ($locale == 'ar') {
    $lang = asset('/plugins/i18n/Arabic.json');
} else {
    $lang = '';
}
$tbl_action = __('labels.tbl_action');
?>


<?php $__env->startSection('head-script'); ?>

    <!-- data tables css -->
    <link rel="stylesheet" href="<?php echo e(asset('/plugins/data-tables/css/datatables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/plugins/data-tables/css/select.dataTables.min.css')); ?>">
    <!-- pnotify css -->
    <link rel="stylesheet" href="<?php echo e(asset('/plugins/pnotify/css/pnotify.custom.min.css')); ?>">
    <!-- pnotify-custom css -->
    <link rel="stylesheet" href="<?php echo e(asset('/css/pages/pnotify.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php echo $__env->make('layouts.partials.breadcrumb', [
    'bread_title'=> $breadcrumb,
    'bread_subtitle'=> $breadcrumb
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <!-- Column Selector table start -->
    <div class="col-sm-12">
        <div class="card">

            <div class="card-header">
                <h5><?php echo e(__('cards.user_list')); ?></h5>
                <div class="card-header-right">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-delete')): ?>
                        <button class="btn btn-danger " id="btn_delete" onclick='return multipleDelete("<?php echo e($locale); ?>");'>
                            <i class="feather icon-trash-2"></i>
                            <?php echo e(__('inputs.btn_delete')); ?>

                            <i id="btn_count"></i>
                        </button>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-create')): ?>
                        <a class="btn btn-primary" href="<?php echo e(route('users.create')); ?>"> <i
                                class="feather icon-plus-circle"></i> <?php echo e(__('inputs.btn_create_user')); ?></a>
                    <?php endif; ?>
                </div>

            </div>
            <div class="card-body">
                <div class="dt-responsive table-responsive">
                    <table id="users-table" class="table table-striped table-bordered nowrap">
                        <thead>
                            <th style="width: 30px"><input type="checkbox" class="select-checkbox" /> </th>
                            <th>id</th>
                            <th><?php echo e(__('labels.tbl_name')); ?></th>
                            <th><?php echo e(__('labels.tbl_email')); ?></th>
                            <th><?php echo e(__('labels.tbl_phone')); ?></th>
                            <th><?php echo e(__('labels.tbl_role')); ?></th>
                            <th><?php echo e(__('labels.tbl_created_at')); ?></th>
                            <th><?php echo e($tbl_action); ?></th>
                        </thead>

                        <tfoot>
                            <tr>
                                <th style="width: 30px"></th>
                                <th>id</th>
                                <th><?php echo e(__('labels.tbl_name')); ?></th>
                                <th><?php echo e(__('labels.tbl_email')); ?></th>
                                <th><?php echo e(__('labels.tbl_phone')); ?></th>
                                <th><?php echo e(__('labels.tbl_role')); ?></th>
                                <th><?php echo e(__('labels.tbl_created_at')); ?></th>
                                <th><?php echo e($tbl_action); ?></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- Column Selector table end -->


<?php $__env->stopSection(); ?>
<?php $__env->startSection('srcipt-js'); ?>
    <!-- datatable Js -->
    <script src="<?php echo e(asset('/plugins/data-tables/js/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/plugins/data-tables/js/dataTables.select.min.js')); ?>"></script>
    <!-- sweet alert Js -->
    <script src="<?php echo e(asset('/plugins/sweetalert/js/sweetalert.min.js')); ?>"></script>
    <!-- pnotify Js -->
    <script src="<?php echo e(asset('/plugins/pnotify/js/pnotify.custom.min.js')); ?>"></script>

    <script>
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            var table = $('#users-table').DataTable({
                //dom: 'Bfrtip',
                initComplete: function() {
                    // Apply the search
                    this.api().columns().every(function() {
                        var that = this;

                        $('input', this.footer()).on('keyup change clear', function() {
                            if (that.search() !== this.value) {
                                that
                                    .search(this.value)
                                    .draw();
                            }
                        });
                    });
                },
                processing: true,
                serverSide: true,
                serverMethod: 'POST',
                ajax: {
                    url: "<?php echo e(route('users_datatable.data')); ?>"
                },
                language: {
                    url: "<?php echo e($lang); ?>"
                },
                columns: [{
                        data: "select",
                        className: "select-checkbox"
                    },
                    {
                        data: "id",
                        className: "id"
                    },
                    {
                        data: "name",
                        className: 'name'
                    },
                    {
                        data: "email",
                        className: 'email'
                    },
                    {
                        data: "phone_num",
                        className: 'phone_num'
                    },
                    {
                        data: "role",
                        className: 'role'
                    },
                    {
                        data: "created_at",
                        className: 'created_at'
                    },
                    {
                        data: 'action',
                        className: 'action',
                        visible: 'false'
                    },
                ],
                responsive: true,

                columnDefs: [{
                        orderable: false,
                        className: 'select-checkbox',
                        targets: 0
                    },
                    {
                        visible: false,
                        targets: 1
                    }
                ],
                select: {
                    style: 'os',
                    selector: 'td:first-child'
                },
                // select: { style: 'multi+shift' },

            });
            table
                .on('select', function(e, dt, type, indexes) {
                    // var rowData = table.rows( indexes ).data().toArray();
                    //console.log( rowData );
                    SelectedRowCountBtnDelete(table)
                })
                .on('deselect', function(e, dt, type, indexes) {
                    SelectedRowCountBtnDelete(table)
                });

            $('.dataTables_length').addClass('bs-select');

            // Setup - add a text input to each footer cell

            addSearchFooterDataTable("#users-table")
        });


        function deleteFromDataTableBtn(id) {
            //  let id = $('#tbl_btn_delete').attr('data-id');

            var url = "<?php echo e(route('users.destroy', ['user' => ':id'])); ?>";
            url = url.replace(':id', id);
            swal({
                    title: "<?php echo e(__('labels.swal_delete_title')); ?>",
                    text: "<?php echo e(__('labels.swal_delete_text')); ?>",
                    icon: "warning",
                    buttons: ["<?php echo e(__('labels.swal_cancel_btn')); ?>", "<?php echo e(__('labels.swal_confirm_btn')); ?>"],
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {

                        $.ajax({
                            type: 'DELETE',
                            dataType: 'JSON',
                            url: url,
                            success: function(response) {
                                console.log(response)
                                //alert(JSON.stringify(response))
                                // refresh data or remove only tr
                                deleteSingleRowDataTable("#users-table")
                                PnotifyCustom(response)


                            }
                        }); // ajax end

                    }
                });
        }

        function multipleDelete(locale) {
            var table = $('#users-table').DataTable();
            var ids = table.rows('.selected').data();
            var url = "<?php echo e(route('users_datatable.multidestroy')); ?>";
            multipleDeleteG(locale, "#users-table", ids, url);
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\MesProjetsLaravel\elite-marche\resources\views/users/index.blade.php ENDPATH**/ ?>