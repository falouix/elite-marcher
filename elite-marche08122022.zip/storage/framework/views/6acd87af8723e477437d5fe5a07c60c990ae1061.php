<?php echo e($slot); ?>

<?php /**PATH F:\MesProjetsLaravel\elite-marche\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>