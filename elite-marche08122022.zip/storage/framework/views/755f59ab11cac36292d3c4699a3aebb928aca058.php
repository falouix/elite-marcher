
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-edit')): ?>

<a href="<?php echo e(route('besoins-validation.edit', $id)); ?>" class="btn btn-icon btn-rounded btn-primary"
        title="المصادقة على الحاجيات">
        <i class="feather icon-edit-1"></i>
    </a>
<?php endif; ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-edit')): ?>

<button type="button"  class="btn btn-icon btn-rounded btn-danger"
        title="المصادقة النهائية على الحاجيات" onclick="validerBesoin(<?php echo e($id); ?>)">
        <i class="feather icon-check-circle"></i>
</button>
<?php endif; ?>
<?php /**PATH F:\MesProjetsLaravel\elite-marche\resources\views/besoins/validation/datatable-actions.blade.php ENDPATH**/ ?>