<div class="form-group">
    <label class="form-label"><?php echo e(__('labels.lbl_role')); ?></label>
   
<select class="form-control" id="roles" name="roles[]" multiple>
   
   <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <option value="<?php echo e($role->name); ?>"
        <?php if(isset($userRole)): ?>
        <?php $__currentLoopData = $userRole; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($role->name == $item ? 'selected': ''); ?>   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
       > <?php echo e($role->$name); ?></option>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
</select>
</div>
<?php /**PATH F:\MesProjetsLaravel\elite-marche\resources\views/components/user_role.blade.php ENDPATH**/ ?>