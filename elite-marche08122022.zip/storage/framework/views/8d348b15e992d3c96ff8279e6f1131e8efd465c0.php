


<?php if($valider == false): ?>
<button  class="btn btn-icon btn-rounded btn-primary"
        title="تفعيل المادة" onclick="validerArticle(<?php echo e($id); ?>)">
        <i class="feather icon-edit-1"></i>
</button>
<?php endif; ?>


    <a href="#" class="btn btn-icon btn-rounded btn-success" data-id="<?php echo e($id); ?>"
        title="<?php echo e(__('inputs.btn_edit')); ?>" onclick="editArticle(<?php echo e($id); ?>)">
        <i class="feather icon-edit"></i>
    </a>



    <button type="button" data-id='<?php echo e($id); ?>' id="tbl_btn_delete" class="btn btn-icon btn-rounded btn-danger"
        title="<?php echo e(__('inputs.btn_delete')); ?>" onclick="deleteFromDataTableBtn(<?php echo e($id); ?>)">
        <i class="feather icon-trash-2"> </i>
    </button>




<?php /**PATH F:\MesProjetsLaravel\elite-marche\resources\views/articles/datatable-actions.blade.php ENDPATH**/ ?>