
<button type="button" data-id='<?php echo e($id); ?>' id="tbl_btn_addLP" class="btn btn-icon btn-rounded btn-info"
title="إضافة إلى محتوى المشروع" onclick="addLPFromTableBtn(<?php echo e($id); ?>)">
<i class="feather icon-plus-square"> </i>
</button>

<?php /**PATH F:\MesProjetsLaravel\elite-marche\resources\views/projets/lignes_projets/editProjet-datatable-actions.blade.php ENDPATH**/ ?>