<!-- [ navigation menu ] start -->
<nav class="pcoded-navbar menupos-fixed ">
    <div class="navbar-wrapper ">
        <div class="navbar-brand header-logo">
            <a href="<?php echo e(url('/')); ?>" class="b-brand">
                <div class="b-bg">
                    L
                </div>
                <span class="b-title"><?php echo e(__('app.app_name')); ?></span>
            </a>
            <a class="mobile-menu" id="mobile-collapse" href="#"><span></span></a>
        </div>
        <div class="navbar-content scroll-div">
            <ul class="nav pcoded-inner-navbar ">
                <li class="nav-item pcoded-menu-caption">
                    <label><?php echo e(__('menu.navigation')); ?></label>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard-list')): ?>
                    <li data-username="Dashboard" class="nav-item"><a href="<?php echo e(route('home')); ?>" class="nav-link"><span
                                class="pcoded-micon"><i class="feather icon-grid"></i></span><span
                                class="pcoded-mtext"><?php echo e(__('menu.dashboard')); ?></span></a></li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('besoins')): ?>
                    <?php if($besoins_actif == true): ?>
                        <li data-username="Expenses ui" class="nav-item pcoded-hasmenu">
                            <a href="#" class="nav-link"><span class="pcoded-micon"><i
                                        class="feather icon-sliders"></i></span><span class="pcoded-mtext">تحديد
                                    الحاجيات</span></a>
                            <ul class="pcoded-submenu">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('besoins-list')): ?>
                                    <li class=""><a href=" <?php echo e(route('besoins.index')); ?>" class="">ضبط الحاجيات</a>
                                    </li>
                                <?php endif; ?>


                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('besoin-validate')): ?>
                                    <li class="">
                                        <a href="<?php echo e(route('besoins-validation.index')); ?>" class="">المصادقة على
                                            الحاجيات</a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('besoin-view')): ?>
                                    <li class=""><a href="<?php echo e(route('pais.index')); ?>" class="">المخطط السنوي
                                            للحاجيات</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('projet-achat')): ?>
                    <li data-username="Expenses ui" class="nav-item pcoded-hasmenu">
                        <a href="#" class="nav-link"><span class="pcoded-micon"><i
                                    class="feather icon-sliders"></i></span><span class="pcoded-mtext"> البرنامج السنوي
                                للشراءات</span></a>
                        <ul class="pcoded-submenu">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('projet-achat-list')): ?>
                                <li class="">
                                    <a href="<?php echo e(route('projets.index')); ?>" class="">مشاريع الشراءات</a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('projet-ppm')): ?>
                                <li class=""><a href=" <?php echo e(route('ppm.index')); ?>" class="">المخطط السنوي
                                        للشراءات</a></li>
                                <li class="">
                                <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dossier-achat')): ?>
                    <li data-username="Expenses ui" class="nav-item pcoded-hasmenu">
                        <a href="#" class="nav-link"><span class="pcoded-micon"><i
                                    class="feather icon-sliders"></i></span><span class="pcoded-mtext">ملفات
                                الشراءات</span></a>
                        <ul class="pcoded-submenu">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('consultations-list')): ?>
                                <li class=""><a href="<?php echo e(route('consultations.index')); ?>" class="">الإستشارات</a>
                                </li>
                            <?php endif; ?>
                            <li class="pcoded-hasmenu"><a href="#" class="">طلبات العروض </a>
                                <ul class="pcoded-submenu">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('AOS-list')): ?>
                                        <li class=""><a href="<?php echo e(route('aos.index')); ?>" class="">إجراءات مبسطة
                                            </a></li>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('AON-list')): ?>
                                        <li class=""><a href="<?php echo e(route('aon.index')); ?>" class="">إجراءات عادية </a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('AOGREGRE-list')): ?>
                                        <li class=""><a href="<?php echo e(route('aogregre.index')); ?>" class="">التفاوض
                                                المباشر</a></li>
                                    <?php endif; ?>
                                </ul>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('comission-ao-achat')): ?>
                    <li class="nav-item pcoded-hasmenu">
                        <a href="#!" class="nav-link">
                            <span class="pcoded-micon">
                                <i class="feather icon-folder"></i>
                            </span>
                            <span class="pcoded-mtext">اللجان المختصة</span>
                        </a>
                        <ul class="pcoded-submenu" style="display: none;">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('comission-ao-list')): ?>
                                <li class=""><a href="#" class="">لجنة الصفقات</a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('comission-achat-list')): ?>
                                <li class=""><a href="#" class="">لجنة الشراءات</a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <!-- settings menu -->
                

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings-general')): ?>
                    <li class="nav-item pcoded-menu-caption">
                        <label><?php echo e(__('menu.settings_menu')); ?></label>
                    </li>
                    <?php if(\Auth::user()->can('settings-update') || \Auth::user()->can('user-list') || \Auth::user()->can('role-list')): ?>
                        <li data-username="Settings ui" class="nav-item pcoded-hasmenu">
                            <a href="#" class="nav-link"><span class="pcoded-micon"><i
                                        class="feather icon-sliders"></i></span><span
                                    class="pcoded-mtext"><?php echo e(__('menu.user-settings')); ?></span></a>
                            <ul class="pcoded-submenu">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-list')): ?>
                                    <li class=""><a href=" <?php echo e(route('users.index')); ?>"
                                            class=""><?php echo e(__('menu.users_list')); ?></a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-list')): ?>
                                    <li class=""><a href="<?php echo e(route('roles.index')); ?>"
                                            class=""><?php echo e(__('menu.users_roles')); ?></a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <!-- settings menu end-->
                    <!-- case-settings menu -->

                    <li data-username="Expenses ui" class="nav-item pcoded-hasmenu">
                        <a href="#" class="nav-link"><span class="pcoded-micon"><i
                                    class="feather icon-sliders"></i></span><span class="pcoded-mtext">إعدادات</span></a>
                        <ul class="pcoded-submenu">

                            <li data-username=" Settings ui">
                                <a href="<?php echo e(route('etablissements.index')); ?>" class="nav-link"><span
                                        class="pcoded-micon"><i class="feather icon-sliders"></i></span><span
                                        class="pcoded-mtext">إعدادات عامة</span></a>

                            </li>
                            <li class="pcoded-hasmenu"><a href="#" class="">المعطيات الأساسية</a>
                                <ul class="pcoded-submenu">
                                    <li class=""><a href=<?php echo e(route('services.index')); ?>

                                            class="">المصالح/الدوائر/المؤسسات</a></li>
                                    <li class=""><a href="<?php echo e(route('natures-demande.index')); ?>"
                                            class="">أنواع
                                            الطلبات</a></li>
                                    <li class=""><a href="<?php echo e(route('articles.index')); ?>" class="">المواد أو
                                            الطلبات</a></li>
                                    <li class=""><a href="<?php echo e(route('soumissionnaires.index')); ?>"
                                            class="">المتعهدين</a></li>
                                </ul>
                            </li>


                    </li>
                <?php endif; ?>
            </ul>
            </li>
            <!-- case-settings menu end-->



            </ul>
        </div>

    </div>
</nav>
<!-- [ navigation menu ] end -->
<?php /**PATH F:\MesProjetsLaravel\elite-marche\resources\views/layouts/partials/menu.blade.php ENDPATH**/ ?>