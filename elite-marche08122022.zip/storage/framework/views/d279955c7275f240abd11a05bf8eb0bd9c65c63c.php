<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('besoins-list')): ?>
    <a href="#" class="btn btn-icon btn-rounded btn-success" data-id="<?php echo e($id); ?>"
        title="<?php echo e(__('inputs.btn_edit')); ?>" onclick="editSoumissionnaire(<?php echo e($id); ?>)">
        <i class="feather icon-edit"></i>
    </a>
<?php endif; ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('besoins-list')): ?>
    <button type="button" data-id='<?php echo e($id); ?>' id="tbl_btn_delete" class="btn btn-icon btn-rounded btn-danger"
        title="<?php echo e(__('inputs.btn_delete')); ?>" onclick="deleteFromDataTableBtn(<?php echo e($id); ?>)">
        <i class="feather icon-trash-2"></i>
    </button>
<?php endif; ?>
<?php /**PATH F:\MesProjetsLaravel\elite-marche\resources\views/soumissionnaires/datatable-actions.blade.php ENDPATH**/ ?>