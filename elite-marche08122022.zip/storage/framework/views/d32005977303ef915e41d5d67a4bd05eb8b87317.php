<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('besoin-view')): ?>

<a href="<?php echo e(route('besoins.show', $id)); ?>" class="btn btn-icon btn-rounded btn-primary"
        title="عرض التفاصيل">
        <i class="feather icon-eye"></i>
    </a>
<?php endif; ?>

<?php if($valider == false): ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('besoin-edit')): ?>
<a href="<?php echo e(route('besoins.edit', $id)); ?>" class="btn btn-icon btn-rounded btn-success"
        title="<?php echo e(__('inputs.btn_edit')); ?>">
        <i class="feather icon-edit"></i>
    </a>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('besoin-delete')): ?>
    <button type="button" data-id='<?php echo e($id); ?>' id="tbl_btn_delete" class="btn btn-icon btn-rounded btn-danger"
        title="<?php echo e(__('inputs.btn_delete')); ?>" onclick="deleteFromDataTableBtn(<?php echo e($id); ?>)">
        <i class="feather icon-trash-2"></i>
    </button>
<?php endif; ?>
<?php endif; ?>
<?php /**PATH F:\MesProjetsLaravel\elite-marche\resources\views/besoins/datatable-actions.blade.php ENDPATH**/ ?>