<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('projet-achat-view')): ?>
    <a href="<?php echo e(route('ppm.show', ['ppm' => $id])); ?>" class="btn btn-icon btn-rounded btn-primary"
        title="<?php echo e(__('inputs.btn_view')); ?>">
        <i class="feather icon-eye"></i>
    </a>
<?php endif; ?>

<?php if($transferer == false): ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('projet-achat-edit')): ?>
        <a href="<?php echo e(route('ppm.edit', $id)); ?>" class="btn btn-icon btn-rounded btn-success"
            title="<?php echo e(__('inputs.btn_edit')); ?>">
            <i class="feather icon-edit"></i>
        </a>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH F:\MesProjetsLaravel\elite-marche\resources\views/projets/ppm/datatable-actions.blade.php ENDPATH**/ ?>