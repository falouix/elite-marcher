<?php
//dd($userService);
if ($locale == 'ar') {
    $lang = asset('/plugins/i18n/Arabic.json');
    $rtl = 'rtl';
} else {
    $lang = '';
}

$breadcrumb = 'ضبط الحاجيات';
$sub_breadcrumb = 'تحيين الحاجيات';
$tbl_action = __('labels.tbl_action');
?>


<?php $__env->startSection('head-script'); ?>
    <!-- data tables css -->
    <link rel="stylesheet" href="<?php echo e(asset('/plugins/data-tables/css/datatables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/plugins/data-tables/css/select.dataTables.min.css')); ?>">
    <!-- pnotify css -->
    <link rel="stylesheet" href="<?php echo e(asset('/plugins/pnotify/css/pnotify.custom.min.css')); ?>">
    <!-- pnotify-custom css -->
    <link rel="stylesheet" href="<?php echo e(asset('/css/pages/pnotify.css')); ?>">
    <!-- select2 css -->
    <link rel="stylesheet" href="<?php echo e(asset('/plugins/select2/css/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>
    <?php echo $__env->make('layouts.partials.breadcrumb', [
        'bread_title' => $breadcrumb,
        'bread_subtitle' => $sub_breadcrumb,
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Column Selector table start -->
    <div class="col-sm-12">
        <div class="card">
            <div class="card-header">
                <h5><?php echo e($sub_breadcrumb); ?></h5>
                <div class="card-header-right">

                    <?php if($besoin->valider == false): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('besoins-list')): ?>
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#add_article">
                                <i class="feather icon-plus-circle"></i> إضافة مادة جديدة
                            </button>
                        <?php endif; ?>
                    <?php endif; ?>
                    <a href="<?php echo e(route('besoins.index')); ?>" class="btn btn-secondary">
                        العودة لضبط الحاجيات
                        <i class="feather icon-corner-down-left"></i>
                    </a>
                </div>
            </div>
            <div class="card-body">
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <strong><?php echo e(__('validation.v_title')); ?></strong><br>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                aria-hidden="true">×</span></button>
                    </div>
                <?php endif; ?>
                <!-- [ Form Validation ] start -->



                
                <?php echo Form::open([
                    'route' => ['besoins.update', $besoin->id],
                    'method' => 'patch',
                    'id' => 'validation-client_form',
                ]); ?>


                <div class="row" style="display: none;">
                    <div class="col-md-12">
                        <div class="form-group ">
                            <label> المصلحة/الدائرة/المؤسسة </label>
                            <input type="text" class="form-control" value="<?php echo e($userService->libelle); ?>" readonly>
                            <input type="hidden" name="services_id" value="<?php echo e($userService->id); ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="date_besoin"> التاريخ </label>
                            <input type="date" class="form-control" id='date_besoin' name="date_besoin"
                                placeholder="أدخل التاريخ" value="<?php echo e($besoin->date_besoin); ?>">
                            <?php if($errors->has('date_besoin')): ?>
                                <span class="text-danger"><?php echo e($errors->first('date_besoin')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="annee_gestion"> السنة المالية </label>
                            <input type="number" class="form-control" id='annee_gestion' name="annee_gestion"
                                placeholder="أدخل السنة المالية" value='<?php echo e($besoin->annee_gestion); ?>' readonly>
                            
                        </div>
                    </div>
                </div>
                <button type="submit" id="btn_submit" class="btn btn-primary" style="float: right;" hidden>
                </button>
                <?php echo Form::close(); ?>

                
                <form id="cp_form" action="#">
                    <input type="hidden" name="lignebesoin_id" id="lignebesoin_id" value="0">
                    <div class="row">
                       

                        <div class="col-md-3">
                            <div class="form-group">
                                <label class="form-label">طبيعة الطلب</label>
                                <select class="form-control" id="type_demande">
                                    <option value="1">مواد وخدمات</option>
                                    <option value="2">أشغال</option>
                                    <option value="3">دراسات</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label class="form-label">نوع الطلب</label>
                                <select class="form-control " id="natures_demande" name="natures_demande">
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">المادة (التسمية)</label>
                                <select class="form-control " id="articles_id" name="articles_id">
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label">الكمية المطلوية</label>
                                <input type="number" class="form-control" name="qte_demande" placeholder="الكمية..."
                                    value="<?php echo e(old('qte_demande')); ?>" onchange="calculTotal()">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label">الكلفة التقديرية للوحدة</label>
                                <input type="number" class="form-control" name="cout_unite_ttc"
                                    placeholder="كلفة الوحدة..." value="<?php echo e(old('cout_unite_ttc')); ?>"
                                    onchange="calculTotal()">
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label">الكلفة التقديرية الجملية</label>
                                <input type="number" class="form-control" name="cout_total_ttc"
                                    placeholder="الكلفة التقديرية الجملية..." value="0" readonly>
                            </div>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="exampleInputEmail1"> إسم الملف المرفق (الخصائص الفنية) </label>
                            <input type="text" class="form-control" name="file_name" id="file_name"
                                placeholder="إسم الملف المرفق" value="">

                        </div>
                        <div class="form-group col-md-6">
                            <label for="exampleInputEmail1">الملف/الوثيقة</label>
                            <input type="file" id="file" name="file" class="form-control form-control-file"
                                id="file">
                            <label id="file-error" class="error jquery-validation-error small form-text invalid-feedback"
                                for="file"></label>
                        </div>
                        <div class="form-group col-md-12">
                            <label for="exampleInputEmail1"> الملاحظات </label>
                            <input type="text" class="form-control" name="description" id="description"
                                placeholder="الملاحظات" value="">

                        </div>

                        <div class="col-md-12">
                            <?php if($besoin->valider == false): ?>
                                <a href="javascript:void(0);" class="btn btn-rounded btn-info" id='add'
                                    for-table='#table-cp'>
                                    <i class="feather icon-plus"></i>
                                    <span class="spinner-border spinner-border-sm" role="status" hidden></span>
                                    <span id="btn_add_poa_title">إضافة إلى الجدول</span>

                                </a>
                            <?php endif; ?>

                            <div class="dt-responsive table-responsive">
                                <h6 style="color: red; text-align: left;">الكلفة الجمليةالتقديرية للحاجيات : <span
                                        id="coutTotal"> </span></h6>

                                <table id="table-cp" class="table table-striped table-bordered nowrap">
                                    <thead>
                                        <th class="not-export-col" style="width: 30px"><input type="checkbox"
                                                class="select-checkbox not-export-col" /> </th>
                                        <th class="not-export-col">id</th>
                                        <th>المادة</th>
                                        <th>طبيعة الطلب</th>
                                        <th>نوع الطلب</th>
                                        <th>الكمية المطلوبة</th>
                                        <th>الكلفة التقديرية للوحدة</th>
                                        <th>الكلفة التقديرية الجملية</th>
                                        <th>الملاحظات</th>
                                        <th>الملف/الوثيقة</th>
                                        <th class="not-export-col"><?php echo e($tbl_action); ?></th>
                                    </thead>

                                    <tfoot>
                                        <tr>
                                            <th class="not-export-col" style="width: 30px"><input type="checkbox"
                                                    class="select-checkbox not-export-col" /> </th>
                                            <th class="not-export-col">id</th>
                                            <th>المادة</th>
                                            <th>طبيعة الطلب</th>
                                            <th>نوع الطلب</th>
                                            <th>الكمية المطلوبة</th>
                                            <th>الكلفة التقديرية للوحدة</th>
                                            <th>الكلفة التقديرية الجملية</th>
                                            <th>الملاحظات</th>
                                            <th>الملف/الوثيقة</th>
                                            <th class="not-export-col"><?php echo e($tbl_action); ?></th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </form>
                


                <div class="row mt-4">
                    <?php if($besoin->valider == false): ?>
                        <button type="button" id="btn_create" class="btn btn-primary" style="float: right;">
                            <i class="feather icon-client-plus"></i>
                            <?php echo e(__('inputs.btn_edit')); ?>

                        </button>
                    <?php endif; ?>
                    <a href="<?php echo e(route('besoins.index')); ?>" class="btn btn-danger" style="float: left;">
                        <i class="feather icon-minus-circle"></i>
                        <?php echo e(__('inputs.btn_cancel')); ?>

                    </a>
                </div>
                <!-- [ Form Validation ] end -->

            </div>
        </div>
    </div>


    <!-- Modal Create or edit status -->
    <div class="modal fade show" id="add_article" tabindex="-1" aria-labelledby="exampleModalLabel" aria-modal="true"
        style="display: none;">
        <div class="modal-dialog ">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal-title"> إضافة مادة جديدة </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="form_id">

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">طبيعة الطلب</label>
                                    <select class="form-control" id="modal_type_demande" name="modal_type_demande">
                                        <option value="1">مواد وخدمات</option>
                                        <option value="2">أشغال</option>
                                        <option value="3">دراسات</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">نوع الطلب</label>

                                    <select class="form-control" id="modal_natures_demande">
                                    </select>
                                    <label id="modal_natures_demande-error"
                                        class="error jquery-validation-error small form-text invalid-feedback"
                                        for="libelle"></label>
                                </div>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="lbl_libelle"> المادة</label>
                                <input type="text" class="form-control" id='modal_libelle' name="modal_libelle"
                                    placeholder="إسم المادة..." value="">
                                <label id="modal_libelle-error"
                                    class="error jquery-validation-error small form-text invalid-feedback"
                                    for="modal_libelle"></label>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        <?php echo e(__('inputs.btn_close')); ?></button>
                    <button class="btn btn-primary" id='btn_add_article'> <?php echo e(__('inputs.btn_create')); ?>

                    </button>
                </div>

            </div>
        </div>
    </div>
    <!-- Modal Create or edit status end-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('srcipt-js'); ?>
    <!-- jquery-validation Js -->
    <script src="<?php echo e(asset('/plugins/jquery-validation/js/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/plugins/inputmask/js/jquery.inputmask.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/plugins/inputmask/js/autoNumeric.js')); ?>"></script>
    <!-- datatable Js -->
    <script src="<?php echo e(asset('/plugins/data-tables/js/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/plugins/data-tables/js/dataTables.select.min.js')); ?>"></script>
    <!-- sweet alert Js -->
    <script src="<?php echo e(asset('/plugins/sweetalert/js/sweetalert.min.js')); ?>"></script>
    <!-- pnotify Js -->
    <script src="<?php echo e(asset('/plugins/pnotify/js/pnotify.custom.min.js')); ?>"></script>
    <!-- form-select-custom Js -->
    <script src="<?php echo e(asset('/plugins/select2/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/plugins/data-tables/js/pdfmake.js')); ?>"></script>
    <script src="<?php echo e(asset('/plugins/data-tables/js/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('/plugins/data-tables/js/sum().js')); ?>"></script>

    <script>
        'use strict';
        $(document).ready(function() {
            $(function() {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                // [ Initialize client-form validation ]
                $('#validation-client_form').validate({
                    ignore: '.ignore, .select2-input',
                    focusInvalid: false,
                    rules: {
                        'full_name': {
                            required: true,
                        },
                        'cp_registration': {
                            required: true,
                        },

                        'email': {
                            required: true,
                            email: true
                        },
                        'cp_contact_email': {
                            required: false,
                            email: true
                        },
                        'pr_mail': {
                            required: true,
                            email: true
                        },
                        'pr_name': {
                            required: true,
                        },

                    },

                    // Errors //

                    errorPlacement: function errorPlacement(error, element) {
                        var $parent = $(element).parents('.form-group');

                        // Do not duplicate errors
                        if ($parent.find('.jquery-validation-error').length) {
                            return;
                        }

                        $parent.append(
                            error.addClass(
                                'jquery-validation-error small form-text invalid-feedback')
                        );
                    },
                    highlight: function(element) {
                        var $el = $(element);
                        var $parent = $el.parents('.form-group');

                        $el.addClass('is-invalid');

                        // Select2 and Tagsinput
                        if ($el.hasClass('select2-hidden-accessible') || $el.attr(
                                'data-role') === 'tagsinput') {
                            $el.parent().addClass('is-invalid');
                        }
                    },
                    unhighlight: function(element) {
                        $(element).parents('.form-group').find('.is-invalid').removeClass(
                            'is-invalid');
                    }
                });
                // [ Initialize client-form validation ]
                $('#cp_form').validate({
                    ignore: '.ignore, .select2-input',
                    focusInvalid: false,
                    rules: {
                        'libelle': {
                            required: true,
                        },
                        'qte_demande': {
                            required: true,
                        },
                        'cout_unite_ttc': {
                            required: true,
                        },
                    },
                    // Errors //

                    errorPlacement: function errorPlacement(error, element) {
                        var $parent = $(element).parents('.form-group');

                        // Do not duplicate errors
                        if ($parent.find('.jquery-validation-error').length) {
                            return;
                        }

                        $parent.append(
                            error.addClass(
                                'jquery-validation-error small form-text invalid-feedback')
                        );
                    },
                    highlight: function(element) {
                        var $el = $(element);
                        var $parent = $el.parents('.form-group');

                        $el.addClass('is-invalid');

                        // Select2 and Tagsinput
                        if ($el.hasClass('select2-hidden-accessible') || $el.attr(
                                'data-role') === 'tagsinput') {
                            $el.parent().addClass('is-invalid');
                        }
                    },
                    unhighlight: function(element) {
                        $(element).parents('.form-group').find('.is-invalid').removeClass(
                            'is-invalid');
                    }
                });
                var table = $('#table-cp').DataTable({
                    dom: 'frltipB',
                    "lengthMenu": [
                        [10, 25, 50, -1],
                        [10, 25, 50, "<?php echo e(__('labels.all')); ?>"]
                    ],
                    buttons: [{
                            text: '<?php echo e(__('inputs.btn_copy')); ?>',
                            extend: 'copyHtml5',
                            exportOptions: {
                                columns: ':visible:not(.not-export-col)'
                            }
                        },
                        {
                            text: '<?php echo e(__('inputs.btn_excel')); ?>',
                            extend: 'excelHtml5',
                            exportOptions: {
                                columns: ':visible:not(.not-export-col)'
                            }
                        },
                        {
                            text: '<?php echo e(__('inputs.btn_pdf')); ?>',
                            extend: 'pdfHtml5',
                            exportOptions: {
                                columns: ':visible:not(.not-export-col)'
                            }
                        },
                        {
                            text: '<?php echo e(__('inputs.btn_print')); ?>',
                            extend: 'print',
                            exportOptions: {
                                columns: ':visible:not(.not-export-col)'
                            }
                        },
                    ],

                    scrollY: true,
                    scrollX: true,
                    scrollCollapse: true,
                    paging: false,
                    fixedColumns: {
                        leftColumns: 0,
                        rightColumns: 1
                    },

                    initComplete: function() {
                        // Apply the search
                        this.api().columns().every(function() {
                            var that = this;

                            $('input', this.footer()).on('keyup change clear',
                                function() {
                                    if (that.search() !== this.value) {
                                        that
                                            .search(this.value)
                                            .draw();
                                    }
                                });
                        });
                    },
                    processing: true,
                    // serverSide: true,
                    serverMethod: 'POST',
                    ajax: {
                        url: "<?php echo e(route('ligne_besoin.datatable')); ?>",
                        data: function(data) {

                            data.besoins_id = "<?php echo e($besoin->id); ?>";
                            data.mode = "all";
                        },
                    },
                    language: {
                        url: "<?php echo e($lang); ?>"
                    },
                    columns: [{
                            data: "select",
                            className: "select-checkbox"
                        },
                        {
                            data: "id",
                            className: "id",
                        },
                        {
                            data: "libelle",
                            className: "libelle"
                        },
                        {
                            data: "type_demande",
                            className: "type_demande"
                        },
                        {
                            data: "nature_demandes_id",
                            className: "nature_demandes_id"
                        },
                        {
                            data: "qte_demande",
                            className: "qte_demande"
                        },
                        {
                            data: "cout_unite_ttc",
                            className: "cout_unite_ttc"
                        },
                        {
                            data: "cout_total_ttc",
                            className: "cout_total_ttc"
                        },
                        {
                            data: 'description',
                            className: 'description',
                        },
                        {
                            data: 'action_file',
                            className: 'action_file',
                            visible: 'false'
                        },

                        {
                            data: 'action',
                            className: 'action',
                            visible: 'false'
                        }
                    ],
                    columnDefs: [{
                            orderable: false,
                            className: 'select-checkbox',
                            targets: 0
                        },
                        {
                            visible: false,
                            targets: 1
                        }
                    ],
                    drawCallback: function() {
                        var api = this.api();
                        $('#coutTotal').html(
                            api.column(7, {
                                page: 'current'
                            }).data().sum()
                        )
                    },
                    select: {
                        style: 'os',
                        selector: 'td:first-child'
                    },
                    // select: { style: 'multi+shift' },

                });
                table
                    .on('select', function(e, dt, type, indexes) {
                        // var rowData = table.rows( indexes ).data().toArray();
                        //console.log( rowData );
                        SelectedRowCountBtnDelete(table)
                    })
                    .on('deselect', function(e, dt, type, indexes) {
                        SelectedRowCountBtnDelete(table)
                    });

                $('.dataTables_length').addClass('bs-select');
                // Setup - add a text input to each footer cell
                addSearchFooterDataTable("#table-cp")
                $("#natures_demande").select2({
                    dir: "<?php echo e($rtl); ?>",
                    // minimumInputLength: 3, // only start searching when the user has input 3 or more characters
                    placeholder: "<?php echo e(__('labels.choose')); ?> ",
                    ajax: {
                        url: "<?php echo e(route('natures-demande.select')); ?>",
                        type: "post",
                        delay: 250,
                        dataType: 'json',
                        data: {
                            type: $('#type_demande').val()
                        },
                    },
                    processResults: function(response) {
                        // alert(JSON.stringify(response))
                        return {
                            results: response
                        };
                    },
                    //cache: true
                });
                $("#articles_id").select2({
                    dir: "<?php echo e($rtl); ?>",
                    // minimumInputLength: 3, // only start searching when the user has input 3 or more characters
                    placeholder: "<?php echo e(__('labels.choose')); ?> ",
                    ajax: {
                        url: "<?php echo e(route('articles.select')); ?>",
                        type: "post",
                        delay: 250,
                        dataType: 'json',
                        data: {
                            natures_demande_id: $('#natures_demande').val()
                        },
                    },
                    processResults: function(response) {
                        // alert(JSON.stringify(response))
                        return {
                            results: response
                        };
                    },
                    //cache: true
                });
                $("#modal_natures_demande").select2({
                    dir: "<?php echo e($rtl); ?>",
                    // minimumInputLength: 3, // only start searching when the user has input 3 or more characters
                    placeholder: "<?php echo e(__('labels.choose')); ?> ",
                    dropdownParent: $("#add_article"),
                    ajax: {
                        url: "<?php echo e(route('natures-demande.select')); ?>",
                        type: "post",
                        delay: 250,
                        dataType: 'json',
                        data: {
                            type: $('#modal_type_demande').val()
                        },
                    },
                    processResults: function(response) {
                        // alert(JSON.stringify(response))
                        return {
                            results: response
                        };
                    },
                    //cache: true

                });
            });

        });


        $('#type_demande').on('change', function(e) {
            var type = e.target.value;
            $.ajax({
                url: "<?php echo e(route('natures-demande.select')); ?>",
                type: "POST",

                data: {
                    type: type
                },
                success: function(data) {
                    $('#natures_demande').empty();
                    $('#natures_demande').append('<option value="NULL">إختر من القائمة</option>');
                    $.each(data.results, function(index, naturdemande) {
                        $('#natures_demande').append('<option value="' + naturdemande.id +
                            '">' +
                            naturdemande.text + '</option>');
                    })
                    $('#natures_demande').select2({
                        dir: "<?php echo e($rtl); ?>",
                    });
                }
            })
        });
        $('#natures_demande').on('change', function(e) {
            var type = e.target.value;
            $.ajax({
                url: "<?php echo e(route('articles.select')); ?>",
                type: "POST",
                data: {
                    natures_demande_id: type
                },
                success: function(data) {
                    $('#articles_id').empty();
                    $('#articles_id').append('<option value="NULL">إختر من القائمة</option>');
                    $.each(data.results, function(index, article) {
                        $('#articles_id').append('<option value="' + article.id +
                            '">' +
                            article.text + '</option>');
                    })
                    $('#articles_id').select2({
                        dir: "<?php echo e($rtl); ?>",
                    });
                }
            })
        });
        $('#modal_type_demande').on('change', function(e) {
            var type = e.target.value;
            $.ajax({
                url: "<?php echo e(route('natures-demande.select')); ?>",
                type: "POST",
                data: {
                    type: type
                },
                success: function(data) {
                    $('#modal_natures_demande').empty();
                    $.each(data.results, function(index, naturdemande) {
                        $('#modal_natures_demande').append('<option value="' + naturdemande.id +
                            '">' +
                            naturdemande.text + '</option>');
                    })
                    $('#modal_natures_demande').select2({
                        dir: "<?php echo e($rtl); ?>",
                        dropdownParent: $("#add_article"),
                    });
                }
            })
        });

        $('#add').click(() => {
            //$('#libelle').removeClass('is-invalid')
            $('.spinner-border').removeAttr('hidden');
            var articleId = $('#articles_id').val()
            if (articleId === null || articleId == 'NULL' || articleId === undefined) {
                swal("<?php echo e(__('labels.swal_warning_title')); ?>", 'الرجاء تحديد المادة',
                    "warning");
                return false;
            }
            let id = $("#lignebesoin_id").val();
            var formData = new FormData();
            formData.append('type_demande', $("#type_demande").val())
            formData.append('nature_demandes_id', $("#natures_demande").val())
            formData.append('articles_id', articleId)
            formData.append('description', $("input[name=description]").val())
            formData.append('file_name', $("input[name=file_name]").val())
            formData.append('qte_demande', $("input[name=qte_demande]").val())
            formData.append('qte_valide', $("input[name=qte_demande]").val())
            formData.append('cout_unite_ttc', $("input[name=cout_total_ttc]").val())
            formData.append('cout_unite_ttc', $("input[name=cout_unite_ttc]").val())
            formData.append('besoins_id', <?php echo e($besoin->id); ?>)
            formData.append('id', $("#lignebesoin_id").val())
            formData.append('file', document.getElementById("file").files[0])
            //alert(file)
            var $type = 'POST'
            var $url = "<?php echo e(route('lignes_besoin.store')); ?>"
            if (id != 0) {
                $type = 'PUT'
                $url = "<?php echo e(route('lignes_besoin.update')); ?>"
                formData.append('_method', 'PUT');
            }
            $.ajax({
                url: $url,
                type: 'POST',
                contentType: false,
                processData: false,
                data: formData,
                success: function(response) {
                    console.log(response)
                    $('.spinner-border').attr('hidden', 'hidden');
                    $('#table-cp').DataTable().ajax.reload();
                    $('#cp_form')[0].reset()
                    //$("#cp_form").get(0).reset()
                    $('#add').html("إضافة إلى الجدول")
                    PnotifyCustom(response)


                },
                error: function(response) {
                    $('.spinner-border').attr('hidden', 'hidden');
                    console.log(JSON.stringify(response.responseJSON));
                    $('.spinner-border').attr('hidden', 'hidden');
                    //  $('#file_name-error').html('')
                    $('#libelle-error').html('')
                    $('#file-error').html('')
                    // alert(JSON.stringify(response.responseJSON.message))
                    if (response.responseJSON.message.libelle != null) {
                        $('#libelle').addClass('is-invalid')
                        $('#libelle-error').text(response.responseJSON.message.poa_title);
                    }

                }
            }); // ajax end
        })
        $('#btn_create').on("click", () => {
            $("#btn_submit").click()
        })

        $('#btn_add_article').click(() => {
            let natures_demande_id = $("#modal_natures_demande").val();
            let libelle = $("input[name=modal_libelle]").val();
            $.ajax({
                url: "<?php echo e(route('articles.storeFromBesoin')); ?>",
                type: "POST",
                data: {
                    'natures_demande_id': $("#modal_natures_demande").val(),
                    'libelle': $("input[name=modal_libelle]").val(),
                },
                success: function(response) {
                    $('#modal_libelle').removeClass('is-invalid')
                    $('#modal_natures_demande').removeClass('is-invalid')
                    $('#add_article').modal('toggle');
                    PnotifyCustom(response)

                },
                error: function(errors) {
                    $('#modal_libelle').removeClass('is-invalid')
                    if (errors.responseJSON.message.libelle != null) {
                        $('#modal_libelle').addClass('is-invalid')
                        $('#modal_libelle-error').text(errors.responseJSON.message.libelle);
                    }
                    $('#modal_natures_demande').removeClass('is-invalid')
                    if (errors.responseJSON.message.natures_demande_id != null) {
                        $('#modal_natures_demande').addClass('is-invalid')
                        $('#modal_natures_demande-error').text(errors.responseJSON.message
                            .natures_demande_id);
                    }
                }
            }); // ajax end
        })
        // OnClose Modal eventListener
        $('#add_article').on('hidden.bs.modal', function() {
            $("#form_id")[0].reset()
        })

        function calculTotal() {
            let qte_demande = $("input[name=qte_demande]").val()
            let cout_unite_ttc = $("input[name=cout_unite_ttc]").val()
            let cout_total_ttc = qte_demande * cout_unite_ttc
            $("input[name=cout_total_ttc]").val(cout_total_ttc)

        }

        function editLigneBesoin(id) {
            $.ajax({
                url: "<?php echo e(route('ligne_besoins.edit')); ?>",
                type: 'GET',
                data: {
                    id: id,
                },
                success: function(response) {
                    // alert(JSON.stringify(response))
                    $("#lignebesoin_id").val(response.id);
                    //$("input[name=libelle]").val(response.libelle)
                    $("input[name=description]").val(response.description)
                    $("input[name=qte_demande]").val(response.qte_demande)
                    $("input[name=cout_unite_ttc]").val(response.cout_unite_ttc)
                    $("input[name=cout_total_ttc]").val(response.cout_total_ttc)
                    // Set selected
                    $("#type_demande").val(response.type_demande)
                    $('#type_demande').trigger('change');
                    console.log("dfdf " + response.nature_demandes_id);
                    var natures_demandeSelect = $('#natures_demande');
                    $.ajax({
                        type: 'GET',
                        url: '/natures_demande/Select2/' + response.nature_demandes_id
                    }).then(function(data) {
                        // create the option and append to Select2
                        var option = new Option(data.libelle, data.id, true, true);
                        natures_demandeSelect.append(option).trigger('change');
                        // manually trigger the `select2:select` event
                        natures_demandeSelect.trigger({
                            type: 'select2:select',
                            params: {
                                data: data
                            }
                        });
                    });
                    var article_Select = $('#articles_id');
                    // create the option and append to Select2
                    var option = new Option(response.libelle, response.articles_id, true, true);
                    article_Select.append(option).trigger('change');
                    // manually trigger the `select2:select` event
                    article_Select.trigger({
                        type: 'select2:select',
                        /*params: {
                            data: data
                        }*/
                    });
                    if (response.document) {
                        $("input[name=file_name]").val(response.document.libelle);
                    }
                    $('#add').html("تحيين الجدول")


                },
                error: function(errors) {
                    $('#add').html("<?php echo e(__('inputs.btn_add_row_cp')); ?>")

                    swal("<?php echo e(__('labels.swal_warning_title')); ?>", errors.responseJSON.message,
                        "warning");
                }
            }); // ajax end
        }

        // Delete session + event
        function deleteFile(id) {
            swal({
                    title: "<?php echo e(__('labels.swal_delete_title')); ?>",
                    text: "<?php echo e(__('labels.swal_delete_text')); ?>",
                    icon: "warning",
                    buttons: ["<?php echo e(__('labels.swal_cancel_btn')); ?>", "<?php echo e(__('labels.swal_confirm_btn')); ?>"],
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {

                        $.ajax({
                            type: 'DELETE',
                            dataType: 'JSON',
                            data: {
                                id: id,
                                param: 'besoin_documents'
                            },
                            url: "<?php echo e(route('files.delete')); ?>",
                            success: function(response) {
                                //console.log(response)
                                //alert(JSON.stringify(response))
                                // refresh data or remove only tr
                                $('#table-cp').DataTable().ajax.reload();
                                PnotifyCustom(response)


                            }
                        }); // ajax end

                    }
                });
        }


        // Delete contact_cp
        function deleteFromDataTableLigneBesoinBtn(id) {
            //  let id = $('#tbl_btn_delete').attr('data-id');
            var url = "<?php echo e(route('ligne_besoins_datatable.destroy')); ?>";
            swal({
                    title: "<?php echo e(__('labels.swal_delete_title')); ?>",
                    text: "<?php echo e(__('labels.swal_delete_text')); ?>",
                    icon: "warning",
                    buttons: ["<?php echo e(__('labels.swal_cancel_btn')); ?>", "<?php echo e(__('labels.swal_confirm_btn')); ?>"],
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        $.ajax({
                            type: 'DELETE',
                            dataType: 'JSON',
                            url: url,
                            data: {
                                id: id,
                            },
                            success: function(response) {
                                console.log(response)
                                //alert(JSON.stringify(response))
                                // refresh data or remove only tr
                                $('#table-cp').DataTable().ajax.reload();
                                PnotifyCustom(response)
                            }
                        }); // ajax end
                    }
                });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\MesProjetsLaravel\elite-marche\resources\views/besoins/edit.blade.php ENDPATH**/ ?>