    <div class="form-group">
        <label class="form-label">التصنيف </label>
        <select class="form-control" name="user_type">
            <option value="">إختر التصنيف ...</option>
            <option value="admin" <?php echo e($userType == 'admin' ? 'selected' : ''); ?>>مشرف عام</option>
            <option value="user" <?php echo e($userType == 'user' ? 'selected' : ''); ?>>مستعمل عادي</option>
            <option value="comOffres" <?php echo e($userType == 'comOffres' ? 'selected' : ''); ?>>عضو لجنة صفقات</option>
            <option value="comAchats" <?php echo e($userType == 'comAchats' ? 'selected' : ''); ?>>عضو لجنة شراءات</option>
        </select>
    </div>
<?php /**PATH F:\MesProjetsLaravel\elite-marche\resources\views/components/user_type.blade.php ENDPATH**/ ?>