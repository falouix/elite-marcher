<?php
$name = 'name_' . $locale;
$breadcrumb = __('breadcrumb.bread_role');
$sub_breadcrumb = __('breadcrumb.bread_role_edit');
?>



<?php $__env->startSection('breadcrumb'); ?>
    <?php echo $__env->make('layouts.partials.breadcrumb', [
    'bread_title'=> $breadcrumb,
    'bread_subtitle'=> $sub_breadcrumb
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Column Selector table start -->
    <div class="col-sm-12">
        <div class="card">
            <div class="card-header">
                <h5><?php echo e($sub_breadcrumb); ?></h5>
                <div class="card-header-right">
                    <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-secondary">
                        <?php echo e(__('inputs.btn_back_roles')); ?>

                        <i class="feather icon-corner-down-left"></i>
                    </a>
                </div>
            </div>
            <div class="card-body">


                <?php echo Form::model($role, ['method' => 'PATCH', 'route' => ['roles.update', $role->id]]); ?>

                <div class="row  ml-3">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="form-label"><?php echo e(__('labels.lbl_libelle_role')); ?></label>
                            <?php
                                $placeholdername = __('labels.lbl_libelle_role');
                            ?>
                            <?php echo Form::text('name', null, ['placeholder' => '' . $placeholdername . '', 'class' => 'form-control']); ?>


                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label"><input type="checkbox" id="checkAll">
                                <?php echo e(__('labels.checkAll')); ?></label>
                        </div>

                    </div>

                    <h4> <?php echo e(__('labels.lbl_role')); ?></h4>

                    <div class="row">


                        <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $permission_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3">
                                <h5><?php echo e($value); ?></h5>
                                <?php $__currentLoopData = $permission_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label>
                                        <?php echo e(Form::checkbox('permission[]', $item->id, in_array($item->id, $rolePermissions) ? true : false, ['class' => 'name'])); ?>

                                        <?php echo e($item->$name); ?>

                                    </label><br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <button type="submit" class="btn btn-primary" style="float: right;">
                        <i class="feather icon-edit-2"></i>
                        <?php echo e(__('inputs.btn_edit')); ?>


                    </button>
                    <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-danger" style="float: left;">
                        <i class="feather icon-minus-circle"></i>
                        <?php echo e(__('inputs.btn_cancel')); ?>

                    </a>
                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('srcipt-js'); ?>
    <script>
        $(document).ready(function() {
            $("#checkAll").click(function() {
                $('input:checkbox').not(this).prop('checked', this.checked);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\MesProjetsLaravel\elite-marche\resources\views/roles/edit.blade.php ENDPATH**/ ?>