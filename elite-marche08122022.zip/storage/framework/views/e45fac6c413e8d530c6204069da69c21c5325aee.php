<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('besoin-edit')): ?>

<a href="<?php echo e(route('dossiers.show', ['id'=> $id])); ?>" class="btn btn-icon btn-rounded btn-primary" title="<?php echo e(__('inputs.btn_view')); ?>">
    <i class="feather icon-eye"></i>
</a>
<?php endif; ?>
<?php /**PATH F:\MesProjetsLaravel\elite-marche\resources\views/dossiers_achats/all-datatable-actions.blade.php ENDPATH**/ ?>