<tr>
<td class="header">
    <img src="http://www.uj.rnu.tn/Ar/static/ar/img/logo.png" class="logo" alt="Université Jendouba Logo">
</td>
</tr>
<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<?php echo e($slot); ?>

</a>
</td>
</tr>
<?php /**PATH F:\MesProjetsLaravel\elite-marche\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>